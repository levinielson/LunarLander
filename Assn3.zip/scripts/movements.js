MyGame.movements.rotateLeft = function(elapsedTime) {

}

MyGame.movements.rotateRight = function(elapsedTime) {

}

MyGame.movements.thrust = function(elapsedTime) {
  
}